var call = new W5Call(document.domainname);
call.on('agentList', function (data) {
    //Emit list of online agent
    for (var i = 0; i < 1; i++) {
        //set online agent name
		$('.canvasnewsdivnewbig2').css('background-image', 'url(' +data[0]["image"] + ')');
		$("#divagent").html(data[0]["name"]);
        document.getElementById('demo').onclick = function () {
            //Open url in popup
           var popup=window.open("https://w5call.w5rtc.in/client#?domain="+document.domainname+"&user=false&ring=0", "W5callDemo", "top=200, left=200, width=290,height=320");
            popup.focus();
        }
    }

});

call.on('noAgent', function (data) {
	$('.canvasnewsdivnewbig2').css('background-image', 'url(image/shadowimage.png)');
    var name = document.getElementById('name');
	$("#divagent").html('Agent Offline');
    document.getElementById('demo').onclick = function () {
        alert('Agent Offline');
    }
});

call.agentStatus();